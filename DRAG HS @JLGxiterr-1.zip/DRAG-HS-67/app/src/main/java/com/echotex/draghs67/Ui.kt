package com.echotex.draghs67

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

fun Context.dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

/** Pembantu UI bertema cyber (hitam, biru elektrik, cyan neon). */
object Ui {
    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun rounded(ctx: Context, fill: Int, stroke: Int, radiusDp: Int = 14): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = ctx.dp(radiusDp).toFloat()
            setColor(fill)
            setStroke(ctx.dp(1).coerceAtLeast(1), stroke)
        }

    fun label(ctx: Context, text: String, sizeSp: Float, colorRes: Int, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            this.text = text
            textSize = sizeSp
            setTextColor(ctx.getColor(colorRes))
            typeface = Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }

    fun neon(tv: TextView, colorRes: Int) {
        tv.setShadowLayer(24f, 0f, 0f, tv.context.getColor(colorRes))
    }

    fun card(ctx: Context, title: String): LinearLayout =
        LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(16), ctx.dp(14))
            background = rounded(ctx, ctx.getColor(R.color.card_bg), ctx.getColor(R.color.electric_blue))
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = ctx.dp(12) }
            addView(label(ctx, title, 12f, R.color.electric_blue, true))
        }

    fun neonButton(ctx: Context, text: String, colorRes: Int, heightDp: Int = 52): Button {
        val c = ctx.getColor(colorRes)
        return Button(ctx).apply {
            this.text = text
            isAllCaps = false
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            setTextColor(c)
            textSize = 16f
            stateListAnimator = null
            background = rounded(ctx, Color.argb(40, Color.red(c), Color.green(c), Color.blue(c)), c, 14)
            layoutParams = LinearLayout.LayoutParams(MATCH, ctx.dp(heightDp)).apply {
                bottomMargin = ctx.dp(10)
            }
            setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN ->
                        v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(80).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                }
                false
            }
        }
    }

    @Suppress("DEPRECATION")
    fun go(from: Activity, target: Class<*>) {
        from.startActivity(Intent(from, target))
        from.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    @Suppress("DEPRECATION")
    fun back(from: Activity) {
        from.finish()
        from.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    /** Membuka halaman izin overlay resmi milik Android untuk aplikasi ini. */
    fun openOverlayPermission(from: Activity) {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${from.packageName}")
        )
        try {
            from.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(
                from,
                "Halaman izin overlay tidak ditemukan. Buka Pengaturan > Aplikasi > DRAG HS 67% > Tampil di atas aplikasi lain.",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}

class SensitivityControl(val view: LinearLayout, val refresh: () -> Unit)

/** Slider 0-100 dengan tombol kurang/tambah. Nilai langsung disimpan ke SettingsRepository. */
fun sensitivityControl(
    ctx: Context,
    repo: SettingsRepository,
    onChange: (Int) -> Unit = {}
): SensitivityControl {
    val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    val valueText = Ui.label(ctx, "", 30f, R.color.neon_cyan, true).apply { gravity = Gravity.CENTER }
    val bar = SeekBar(ctx).apply {
        max = 100
        val tint = ColorStateList.valueOf(ctx.getColor(R.color.neon_cyan))
        progressTintList = tint
        thumbTintList = tint
        layoutParams = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
    }

    fun show(v: Int) {
        valueText.text = "$v%"
        if (bar.progress != v) bar.progress = v
    }

    fun commit(v: Int) {
        val n = v.coerceIn(0, 100)
        repo.sensitivity = n
        show(n)
        onChange(n)
    }

    bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (fromUser) commit(progress)
        }

        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    })

    fun stepButton(text: String, delta: Int): Button =
        Ui.neonButton(ctx, text, R.color.electric_blue, 48).apply {
            minWidth = 0
            minimumWidth = 0
            setPadding(0, 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(ctx.dp(52), ctx.dp(48))
            setOnClickListener { commit(repo.sensitivity + delta) }
        }

    val row = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(stepButton("-", -1))
        addView(bar)
        addView(stepButton("+", 1))
    }
    root.addView(valueText)
    root.addView(row)
    show(repo.sensitivity)
    return SensitivityControl(root) { show(repo.sensitivity) }
}
