package com.echotex.draghs67

/** Preset bernama: hanya label + nilai sensitivitas latihan. Tidak berpengaruh ke Free Fire. */
data class Preset(val label: String, val value: Int)

object Presets {
    val ALL = listOf(
        Preset("drag HS 67% @levinxiterr", 67),
        Preset("drag HS 67% @gioproxxy", 67),
        Preset("drag sensi 67% @emeng", 67)
    )
}
